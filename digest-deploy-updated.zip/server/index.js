const express = require('express');
const cors = require('cors');
const fetch = require('node-fetch');

const app = express();
const PORT = 3001;

app.use(cors());

app.get('/api/fetch', async (req, res) => {
  const targetUrl = req.query.url;

  if (!targetUrl) {
    return res.status(400).json({ error: 'URL parameter is required' });
  }

  const fetchWithHeaders = async (url) => {
    return await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
        'Cache-Control': 'no-cache'
      }
    });
  };

  try {
    const response = await fetchWithHeaders(targetUrl).catch(err => {
      // Catch network-level errors (like SSL issues, DNS lookup failures)
      // and throw them so they are caught by the outer try-catch block 
      // and trigger the Jina fallback.
      throw new Error(`Network error during initial fetch: ${err.message}`);
    });

    if (!response.ok) {
      throw new Error(`Failed to fetch URL: ${response.status} ${response.statusText}`);
    }

    const html = await response.text();

    // basic check if we got some sensible HTML back (helps catch bot blocks that return 200)
    if (!html || html.length < 500) {
      throw new Error('Retrieved content seems too short or blocked.');
    }

    res.send(html);
  } catch (error) {
    console.log(`Primary fetch failed (${error.message}), trying Jina AI fallback...`);
    try {
      const jinaUrl = `https://r.jina.ai/${targetUrl}`;
      const jinaResponse = await fetchWithHeaders(jinaUrl);

      if (!jinaResponse.ok) {
        throw new Error(`Jina fallback failed: ${jinaResponse.status} ${jinaResponse.statusText}`);
      }

      const jinaHtml = await jinaResponse.text();
      res.send(jinaHtml);
    } catch (jinaError) {
      console.error('Jina fetch also failed:', jinaError);
      res.status(500).json({
        error: 'This site is blocking access. Try copying the article text and using Paste raw text instead.',
        details: jinaError.message
      });
    }
  }
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
