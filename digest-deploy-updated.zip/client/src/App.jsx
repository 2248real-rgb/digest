import { useState, useRef, useEffect } from 'react';
import { Readability } from '@mozilla/readability';
import DOMPurify from 'dompurify';
import TurndownService from 'turndown';
import { Copy, Loader2, BookOpen, Upload } from 'lucide-react';
import * as pdfjsLib from 'pdfjs-dist';
import './index.css';

pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.js`;

function App() {
  const [activeTab, setActiveTab] = useState('url'); // 'url', 'text', or 'pdf'
  const [inputValue, setInputValue] = useState('');
  const [pdfFile, setPdfFile] = useState(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [article, setArticle] = useState(null);
  const [copySuccess, setCopySuccess] = useState(false);

  const articleRef = useRef(null);

  useEffect(() => {
    if (articleRef.current && article) {
      articleRef.current.classList.add('fade-in');
    }
  }, [article]);

  const handleProcess = async () => {
    if ((activeTab !== 'pdf' && !inputValue.trim()) || (activeTab === 'pdf' && !pdfFile)) return;

    setIsLoading(true);
    setError(null);
    setArticle(null);
    setCopySuccess(false);

    try {
      let htmlToParse = '';
      let urlObj = null;

      if (activeTab === 'url') {
        try {
          urlObj = new URL(inputValue);
        } catch (e) {
          throw new Error('Please enter a valid URL including http:// or https://');
        }

        const res = await fetch(`/api/fetch?url=${encodeURIComponent(inputValue)}`);
        if (!res.ok) {
          // If the backend returns a 500 JSON, we try to parse it to show the correct fallback error from server
          let errorMsg = `Server returned ${res.status}: ${res.statusText}`;
          try {
            const errData = await res.json();
            if (errData.error) errorMsg = errData.error;
          } catch (e) { }
          throw new Error(errorMsg);
        }
        htmlToParse = await res.text();
      } else if (activeTab === 'text') {
        // Fallback for raw text - wrap it in basic HTML structure so Readability can try to parse it
        htmlToParse = `<html><head><title>Pasted Text</title></head><body><div>${inputValue.replace(/\n/g, '<br/>')}</div></body></html>`;
      } else if (activeTab === 'pdf') {
        const arrayBuffer = await pdfFile.arrayBuffer();
        const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
        let fullText = '';
        for (let i = 1; i <= pdf.numPages; i++) {
          const page = await pdf.getPage(i);
          const content = await page.getTextContent();
          fullText += content.items.map(item => item.str).join(' ') + '\n\n';
        }
        htmlToParse = `<html><head><title>${pdfFile.name}</title></head><body><div>${fullText.replace(/\n/g, '<br/>')}</div></body></html>`;
      }

      const doc = new DOMParser().parseFromString(htmlToParse, 'text/html');
      const reader = new Readability(doc);
      const parsedArticle = reader.parse();

      if (!parsedArticle) {
        throw new Error('Could not parse article from the provided content.');
      }

      // Calculate reading time (approx 200 words per minute)
      const wordCount = parsedArticle.textContent ? parsedArticle.textContent.split(/\s+/).length : 0;
      const readingTime = Math.max(1, Math.ceil(wordCount / 200));

      const cleanHtml = DOMPurify.sanitize(parsedArticle.content);

      setArticle({
        title: parsedArticle.title || (activeTab === 'pdf' ? pdfFile.name : 'Untitled'),
        byline: parsedArticle.byline || '',
        domain: urlObj ? urlObj.hostname : (activeTab === 'pdf' ? 'PDF Document' : 'Raw Text Input'),
        readingTime,
        content: cleanHtml
      });

    } catch (err) {
      console.error(err);
      setError(err.message || 'An unexpected error occurred while processing the content.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopyMarkdown = () => {
    if (!article) return;

    try {
      const turndownService = new TurndownService({
        headingStyle: 'atx',
        codeBlockStyle: 'fenced'
      });

      const markdown = turndownService.turndown(article.content);
      const fullContent = `# ${article.title}\n\n*Source: ${article.domain}*${article.byline ? ` | *By: ${article.byline}*` : ''}\n\n---\n\n${markdown}`;

      navigator.clipboard.writeText(fullContent).then(() => {
        setCopySuccess(true);
        setTimeout(() => setCopySuccess(false), 2000);
      });
    } catch (err) {
      console.error('Failed to copy to clipboard', err);
      // Fallback or ignore
    }
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragging(false);

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      if (file.type === 'application/pdf') {
        setPdfFile(file);
        setError(null);
      } else {
        setError('Please upload a valid PDF file.');
      }
    }
  };

  const handleFileSelect = (e) => {
    if (e.target.files && e.target.files.length > 0) {
      const file = e.target.files[0];
      if (file.type === 'application/pdf') {
        setPdfFile(file);
        setError(null);
      } else {
        setError('Please upload a valid PDF file.');
      }
    }
  };

  return (
    <div className="app-container">
      <header className="header">
        <a href="/" className="logo">Digest</a>
        {article && (
          <div className="meta-item" style={{ color: 'var(--text-muted)' }}>
            <BookOpen size={16} />
            <span>{article.readingTime} min read</span>
          </div>
        )}
      </header>

      <main className="main-content">
        <section className={`input-section ${article ? 'minimized' : ''}`}>
          <div className="tabs">
            <button
              className={`tab-btn ${activeTab === 'url' ? 'active' : ''}`}
              onClick={() => { setActiveTab('url'); setInputValue(''); setError(null); }}
            >
              Paste a URL
            </button>
            <button
              className={`tab-btn ${activeTab === 'text' ? 'active' : ''}`}
              onClick={() => { setActiveTab('text'); setInputValue(''); setError(null); }}
            >
              Paste raw text
            </button>
            <button
              className={`tab-btn ${activeTab === 'pdf' ? 'active' : ''}`}
              onClick={() => { setActiveTab('pdf'); setPdfFile(null); setError(null); }}
            >
              Upload PDF
            </button>
          </div>

          <div className="input-group">
            {activeTab === 'url' && (
              <input
                type="url"
                className="input-field"
                placeholder="https://example.com/article"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleProcess()}
                disabled={isLoading}
              />
            )}
            {activeTab === 'text' && (
              <textarea
                className="input-field"
                placeholder="Paste article text or HTML here..."
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                disabled={isLoading}
              />
            )}
            {activeTab === 'pdf' && (
              <div
                className={`drop-zone ${isDragging ? 'dragging' : ''} ${pdfFile ? 'has-file' : ''}`}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                onClick={() => document.getElementById('pdf-upload')?.click()}
              >
                <input
                  type="file"
                  id="pdf-upload"
                  accept="application/pdf"
                  className="hidden-input"
                  onChange={handleFileSelect}
                  disabled={isLoading}
                />

                {pdfFile ? (
                  <div className="file-info">
                    <BookOpen size={24} className="file-icon" />
                    <span className="file-name">{pdfFile.name}</span>
                    <span className="file-size">({(pdfFile.size / 1024 / 1024).toFixed(2)} MB)</span>
                    <button
                      className="clear-file-btn"
                      onClick={(e) => {
                        e.stopPropagation();
                        setPdfFile(null);
                        document.getElementById('pdf-upload').value = '';
                      }}
                    >
                      Remove
                    </button>
                  </div>
                ) : (
                  <div className="drop-content">
                    <Upload size={32} className="upload-icon" />
                    <p>Drop your PDF here or click to browse</p>
                  </div>
                )}
              </div>
            )}

            {error && <div className="error-message">{error}</div>}

            <button
              className="submit-btn"
              onClick={handleProcess}
              disabled={isLoading || (activeTab !== 'pdf' ? !inputValue.trim() : !pdfFile)}
            >
              {isLoading ? (
                <div className="loading-spinner">
                  <Loader2 className="animate-spin" size={20} />
                  <span>Digesting...</span>
                </div>
              ) : (
                'Digest It'
              )}
            </button>
          </div>
        </section>

        {article && (
          <article className="article-container" ref={articleRef}>
            <header className="article-header">
              <h1 className="article-title">{article.title}</h1>
              <div className="article-meta">
                {article.byline && <span>{article.byline}</span>}
                {article.byline && <span>•</span>}
                <span>{article.domain}</span>
              </div>
            </header>

            <hr className="article-divider" />

            <div
              className="article-content"
              dangerouslySetInnerHTML={{ __html: article.content }}
            />

            <div className="article-actions">
              <button className="ghost-btn" onClick={handleCopyMarkdown}>
                {copySuccess ? (
                  <>Copied!</>
                ) : (
                  <>
                    <Copy size={18} />
                    Copy as Markdown
                  </>
                )}
              </button>
            </div>
          </article>
        )}
      </main>
    </div>
  );
}

export default App;
